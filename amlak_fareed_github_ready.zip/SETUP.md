
# راه‌اندازی
1. `flutter create .`
2. فایل‌های این بسته را روی پروژه جدید کپی کنید.
3. `flutter pub get`
4. `flutter analyze`
5. `flutter test`
6. `flutter build apk --release`

برای اعلان زمان‌بندی‌شده، نسخه‌های جدید flutter_local_notifications به تنظیمات Android/Gradle و manifest مخصوص نیاز دارند؛ قبل از release تنظیمات رسمی نسخه نصب‌شده را اعمال کنید.
