import 'package:flutter_test/flutter_test.dart';import 'package:amlak_fareed/core/utils/formatters.dart';
void main(){test('money',()=>expect(money(8500000000),'8,500,000,000'));test('sqm',()=>expect(pricePerMeter(1000000000,100),'10,000,000'));}
