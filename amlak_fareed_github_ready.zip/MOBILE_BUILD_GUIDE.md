# راهنمای ساخت APK فقط با موبایل

## 1) GitHub
- وارد GitHub شوید و یک Repository خالی بسازید؛ مثلاً `amlak-fareed`.
- Repository را Public یا Private بگذارید.

## 2) آپلود
محتویات این ZIP را در ریشه Repository آپلود کنید؛ فایل `pubspec.yaml` باید مستقیماً در ریشه باشد.
همچنین پوشه `.github/workflows/build-apk.yml` باید حفظ شود.

## 3) Build
بعد از Commit:
- به تب Actions بروید.
- workflow با نام `Build APK` را انتخاب کنید.
- اگر دستی اجرا می‌کنید: `Run workflow`.
- صبر کنید تا سبز شود.

## 4) دریافت APK
وارد اجرای موفق workflow شوید و در بخش Artifacts فایل
`amlak-fareed-release-apk`
را دانلود کنید. ZIP آرتیفکت را باز کنید و `app-release.apk` را روی گوشی نصب کنید.

## نکته
این APK برای نصب و تست است و امضای انتشار Google Play ندارد. برای انتشار در Play Store باید signing و AAB تنظیم شود.
