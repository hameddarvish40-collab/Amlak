import 'package:flutter/material.dart';import '../models/property.dart';import '../core/utils/formatters.dart';
class PropertyCard extends StatelessWidget{
 final Property p;final VoidCallback onTap;final VoidCallback onArchive;final VoidCallback onDelete;
 const PropertyCard({super.key,required this.p,required this.onTap,required this.onArchive,required this.onDelete});
 @override Widget build(BuildContext c)=>Card(child:ListTile(onTap:onTap,title:Text('${p.transactionType} ${p.propertyType} • ${p.area.toStringAsFixed(0)} متر'),
 subtitle:Text(p.transactionType=='فروش'?'${money(p.salePrice)} تومان':'ودیعه ${money(p.deposit)} • اجاره ${money(p.rent)}'),leading:CircleAvatar(child:Icon(p.transactionType=='فروش'?Icons.sell_outlined:Icons.key_outlined)),
 onLongPress:()=>showModalBottomSheet(context:c,builder:(_)=>SafeArea(child:Column(mainAxisSize:MainAxisSize.min,children:[
 ListTile(leading:const Icon(Icons.edit),title:const Text('ویرایش'),onTap:()=>Navigator.pop(c,'edit')),
 ListTile(leading:const Icon(Icons.archive_outlined),title:const Text('بایگانی'),onTap:(){Navigator.pop(c);onArchive();}),
 ListTile(leading:const Icon(Icons.delete_outline),title:const Text('حذف'),onTap:(){Navigator.pop(c);onDelete();})
 ])))));
}
