import 'package:intl/intl.dart';
String money(num? n)=>n==null?'—':NumberFormat('#,##0','en_US').format(n);
String pricePerMeter(int? p,double area)=>p==null||area<=0?'—':money((p/area).round());
