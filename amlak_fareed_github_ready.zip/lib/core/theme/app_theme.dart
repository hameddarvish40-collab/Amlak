import 'package:flutter/material.dart';
class AppTheme{
 static final light=ThemeData(
  useMaterial3:true,colorSchemeSeed:const Color(0xff315c72),scaffoldBackgroundColor:const Color(0xfff7f8fa),
  inputDecorationTheme:InputDecorationTheme(
   filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none),
   enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none),
   focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(14))
  ),
  cardTheme:CardThemeData(elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)))
 );
}
