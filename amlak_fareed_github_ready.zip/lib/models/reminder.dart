class Reminder{
 final int? id,propertyId; final DateTime date; final String time,text;
 const Reminder({this.id,required this.propertyId,required this.date,required this.time,required this.text});
 Map<String,Object?> toMap()=>{'id':id,'property_id':propertyId,'date':date.millisecondsSinceEpoch,'time':time,'text':text};
 factory Reminder.fromMap(Map<String,Object?> m)=>Reminder(id:m['id'] as int?,propertyId:m['property_id'] as int?,
 date:DateTime.fromMillisecondsSinceEpoch(m['date'] as int),time:m['time'] as String,text:m['text'] as String);
}
