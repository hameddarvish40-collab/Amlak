class Property{
 final int? id; final String transactionType,propertyType,direction,category;
 final double area; final int bedrooms,buildYear; final int? salePrice,deposit,rent;
 final String ownerName,ownerPhone,description; final List<String> statuses,amenities;
 final bool isArchived; final DateTime createdAt,updatedAt;
 const Property({this.id,required this.transactionType,required this.propertyType,required this.area,
 required this.bedrooms,required this.direction,required this.buildYear,this.salePrice,this.deposit,this.rent,
 this.ownerName='',this.ownerPhone='',this.description='',required this.category,this.statuses=const[],this.amenities=const[],
 this.isArchived=false,required this.createdAt,required this.updatedAt});
 Map<String,Object?> toMap()=>{'id':id,'transaction_type':transactionType,'property_type':propertyType,'area':area,
 'bedrooms':bedrooms,'direction':direction,'build_year':buildYear,'sale_price':salePrice,'deposit':deposit,'rent':rent,
 'owner_name':ownerName,'owner_phone':ownerPhone,'description':description,'category':category,
 'statuses':statuses.join('|'),'amenities':amenities.join('|'),'is_archived':isArchived?1:0,
 'created_at':createdAt.millisecondsSinceEpoch,'updated_at':updatedAt.millisecondsSinceEpoch};
 factory Property.fromMap(Map<String,Object?> m)=>Property(id:m['id'] as int?,transactionType:m['transaction_type'] as String,
 propertyType:m['property_type'] as String,area:(m['area'] as num).toDouble(),bedrooms:m['bedrooms'] as int,
 direction:m['direction'] as String,buildYear:m['build_year'] as int,salePrice:m['sale_price'] as int?,
 deposit:m['deposit'] as int?,rent:m['rent'] as int?,ownerName:(m['owner_name'] as String?)??'',
 ownerPhone:(m['owner_phone'] as String?)??'',description:(m['description'] as String?)??'',
 category:m['category'] as String,statuses:((m['statuses'] as String?)??'').split('|').where((x)=>x.isNotEmpty).toList(),
 amenities:((m['amenities'] as String?)??'').split('|').where((x)=>x.isNotEmpty).toList(),
 isArchived:(m['is_archived'] as int)==1,createdAt:DateTime.fromMillisecondsSinceEpoch(m['created_at'] as int),
 updatedAt:DateTime.fromMillisecondsSinceEpoch(m['updated_at'] as int));
 Property copyWith({int? id,String? transactionType,String? propertyType,double? area,int? bedrooms,String? direction,
 int? buildYear,int? salePrice,int? deposit,int? rent,String? ownerName,String? ownerPhone,String? description,
 String? category,List<String>? statuses,List<String>? amenities,bool? isArchived,DateTime? createdAt,DateTime? updatedAt})=>Property(
 id:id??this.id,transactionType:transactionType??this.transactionType,propertyType:propertyType??this.propertyType,
 area:area??this.area,bedrooms:bedrooms??this.bedrooms,direction:direction??this.direction,buildYear:buildYear??this.buildYear,
 salePrice:salePrice??this.salePrice,deposit:deposit??this.deposit,rent:rent??this.rent,ownerName:ownerName??this.ownerName,
 ownerPhone:ownerPhone??this.ownerPhone,description:description??this.description,category:category??this.category,
 statuses:statuses??this.statuses,amenities:amenities??this.amenities,isArchived:isArchived??this.isArchived,
 createdAt:createdAt??this.createdAt,updatedAt:updatedAt??this.updatedAt);
}
