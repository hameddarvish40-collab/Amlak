class PropertyImage{
 final int? id,propertyId; final String localPath; final int sortOrder; final DateTime createdAt;
 const PropertyImage({this.id,required this.propertyId,required this.localPath,required this.sortOrder,required this.createdAt});
 Map<String,Object?> toMap()=>{'id':id,'property_id':propertyId,'local_path':localPath,'sort_order':sortOrder,'created_at':createdAt.millisecondsSinceEpoch};
 factory PropertyImage.fromMap(Map<String,Object?> m)=>PropertyImage(id:m['id'] as int?,propertyId:m['property_id'] as int?,
 localPath:m['local_path'] as String,sortOrder:m['sort_order'] as int,createdAt:DateTime.fromMillisecondsSinceEpoch(m['created_at'] as int));
}
