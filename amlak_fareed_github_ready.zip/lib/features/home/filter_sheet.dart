import 'package:flutter/material.dart';import '../../core/constants/app_constants.dart';import '../../models/property.dart';import '../../repositories/property_repository.dart';
class FilterSheet extends StatefulWidget{final void Function(List<Property>) onApply;const FilterSheet({super.key,required this.onApply});@override State<FilterSheet> createState()=>_FilterState();}
class _FilterState extends State<FilterSheet>{
 final minP=TextEditingController(),maxP=TextEditingController(),minA=TextEditingController(),maxA=TextEditingController(),minY=TextEditingController(),maxY=TextEditingController();String? transaction;final beds=<int>{};final types=<String>{},dirs=<String>{},ams=<String>{},sts=<String>{},cats=<String>{};
 Widget field(TextEditingController c,String l)=>TextField(controller:c,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:l));
 Widget chips<T>(String title,List<T> all,Set<T> sel,String Function(T) text)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),Wrap(children:all.map((x)=>FilterChip(label:Text(text(x)),selected:sel.contains(x),onSelected:(v)=>setState(()=>v?sel.add(x):sel.remove(x))).padding(const EdgeInsets.all(2))).toList())]);
 @override Widget build(BuildContext c)=>SafeArea(child:Padding(padding:const EdgeInsets.all(16),child:ListView(shrinkWrap:true,children:[
 const Text('فیلتر',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),Row(children:[Expanded(child:field(minP,'حداقل قیمت')),const SizedBox(width:8),Expanded(child:field(maxP,'حداکثر قیمت'))]),
 Row(children:[Expanded(child:field(minA,'حداقل متراژ')),const SizedBox(width:8),Expanded(child:field(maxA,'حداکثر متراژ'))]),
 Row(children:[Expanded(child:field(minY,'حداقل سال')),const SizedBox(width:8),Expanded(child:field(maxY,'حداکثر سال'))]),
 const SizedBox(height:8),chips<int>('تعداد خواب',[1,2,3,4,5],beds,(x)=>x==5?'بیشتر':'$x'),
 chips<String>('نوع ملک',propertyTypes,types,(x)=>x),chips<String>('جهت',directions,dirs,(x)=>x),chips<String>('امکانات',amenities,ams,(x)=>x),
 chips<String>('وضعیت',statuses,sts,(x)=>x),chips<String>('دسته‌بندی',categories,cats,(x)=>x),
 DropdownButtonFormField<String>(value:transaction,decoration:const InputDecoration(labelText:'نوع معامله'),items:[const DropdownMenuItem(value:null,child:Text('همه')), ...transactions.map((x)=>DropdownMenuItem(value:x,child:Text(x)))],onChanged:(v)=>setState(()=>transaction=v)),
 Row(children:[Expanded(child:FilledButton(onPressed:()async{final r=await PropertyRepository().filter(transaction:transaction,minArea:double.tryParse(minA.text),maxArea:double.tryParse(maxA.text),minYear:int.tryParse(minY.text),maxYear:int.tryParse(maxY.text),minPrice:int.tryParse(minP.text),maxPrice:int.tryParse(maxP.text),bedrooms:beds.toList(),types:types.toList(),dirs:dirs.toList(),ams:ams.toList(),sts:sts.toList(),cats:cats.toList());widget.onApply(r);if(c.mounted)Navigator.pop(c);},child:const Text('اعمال فیلتر'))),const SizedBox(width:8),Expanded(child:OutlinedButton(onPressed:(){setState((){transaction=null;beds.clear();types.clear();dirs.clear();ams.clear();sts.clear();cats.clear();for(final x in [minP,maxP,minA,maxA,minY,maxY])x.clear();});},child:const Text('حذف همه فیلترها')))])
 ])));
}
extension on Widget{Widget padding(EdgeInsets e)=>Padding(padding:e,child:this);}
