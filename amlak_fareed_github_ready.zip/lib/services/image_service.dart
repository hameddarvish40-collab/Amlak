import 'dart:io';import 'package:flutter_image_compress/flutter_image_compress.dart';import 'package:image_picker/image_picker.dart';import 'package:path/path.dart' as p;import 'package:path_provider/path_provider.dart';
class ImageService{
 final picker=ImagePicker();
 Future<String?> pick(ImageSource source)async{final x=await picker.pickImage(source:source);if(x==null)return null;final d=await getApplicationDocumentsDirectory();final dir=Directory(p.join(d.path,'property_images'));await dir.create(recursive:true);final out=p.join(dir.path,'${DateTime.now().microsecondsSinceEpoch}.jpg');final f=await FlutterImageCompress.compressAndGetFile(x.path,out,quality:82,minWidth:1600,minHeight:1600);return f?.path;}
}
