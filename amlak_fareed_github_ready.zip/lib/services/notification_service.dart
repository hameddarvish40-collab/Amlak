import 'package:flutter_local_notifications/flutter_local_notifications.dart';
class NotificationService{
 NotificationService._();static final instance=NotificationService._();final plugin=FlutterLocalNotificationsPlugin();
 Future<void> init()async{const android=AndroidInitializationSettings('@mipmap/ic_launcher');await plugin.initialize(const InitializationSettings(android:android));}
 Future<void> show(int id,String text)async{const d=NotificationDetails(android:AndroidNotificationDetails('amlak_reminders','یادآوری املاک',importance:Importance.high,priority:Priority.high));await plugin.show(id,'یادآوری املاک فرید',text,d);}
 Future<void> cancel(int id)=>plugin.cancel(id);
}
