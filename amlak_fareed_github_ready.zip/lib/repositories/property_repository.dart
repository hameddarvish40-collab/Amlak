import '../database/app_database.dart';import '../models/property.dart';
class PropertyRepository{
 final db=AppDatabase.instance.db;
 Future<int> insert(Property p)=>db.insert('properties',p.toMap());
 Future<void> update(Property p)=>db.update('properties',p.toMap(),where:'id=?',whereArgs:[p.id]);
 Future<void> delete(int id)async{await db.delete('reminders',where:'property_id=?',whereArgs:[id]);await db.delete('property_images',where:'property_id=?',whereArgs:[id]);await db.delete('properties',where:'id=?',whereArgs:[id]);}
 Future<List<Property>> all({bool archived=false,String sort='جدیدترین'})async{
  var order='created_at DESC'; if(sort=='قدیمی‌ترین')order='created_at ASC'; if(sort=='ارزان‌ترین')order='COALESCE(sale_price,deposit+rent) ASC'; if(sort=='گران‌ترین')order='COALESCE(sale_price,deposit+rent) DESC'; if(sort=='کمترین متراژ')order='area ASC'; if(sort=='بیشترین متراژ')order='area DESC';
  final r=await db.query('properties',where:'is_archived=?',whereArgs:[archived?1:0],orderBy:order);return r.map(Property.fromMap).toList();
 }
 Future<List<Property>> search(String q,{bool archived=false})async{final allp=await all(archived:archived);final s=q.trim().toLowerCase();if(s.isEmpty)return allp;
 return allp.where((p)=>[p.ownerName,p.ownerPhone,p.propertyType,p.transactionType,p.category,p.direction,p.description,p.buildYear,p.area,p.salePrice,p.deposit,p.rent,...p.statuses,...p.amenities].join(' ').toLowerCase().contains(s)).toList();}
 Future<List<Property>> filter({bool archived=false,String? transaction,double? minArea,double? maxArea,int? minYear,int? maxYear,int? minPrice,int? maxPrice,List<int>? bedrooms,List<String>? types,List<String>? dirs,List<String>? ams,List<String>? sts,List<String>? cats,String sort='جدیدترین'})async{
  var r=await all(archived:archived,sort:sort);
  return r.where((p){
   final price=p.transactionType=='فروش'?p.salePrice:(p.deposit??0)+(p.rent??0);
   return (transaction==null||p.transactionType==transaction)&&(minArea==null||p.area>=minArea!)&&(maxArea==null||p.area<=maxArea!)&&
   (minYear==null||p.buildYear>=minYear!)&&(maxYear==null||p.buildYear<=maxYear!)&&(minPrice==null||(price??0)>=minPrice!)&&(maxPrice==null||(price??0)<=maxPrice!)&&
   (bedrooms==null||bedrooms.isEmpty||bedrooms.contains(p.bedrooms)||(bedrooms.contains(5)&&p.bedrooms>=5))&&(types==null||types.isEmpty||types.contains(p.propertyType))&&
   (dirs==null||dirs.isEmpty||dirs.contains(p.direction))&&(ams==null||ams.every(p.amenities.contains))&&(sts==null||sts.isEmpty||sts.any(p.statuses.contains))&&
   (cats==null||cats.isEmpty||cats.contains(p.category));
  }).toList();
 }
}
