import '../database/app_database.dart';import '../models/reminder.dart';
class ReminderRepository{
 final db=AppDatabase.instance.db;
 Future<int> insert(Reminder r)=>db.insert('reminders',r.toMap());
 Future<void> delete(int id)=>db.delete('reminders',where:'id=?',whereArgs:[id]);
 Future<List<Reminder>> forProperty(int id)async{final r=await db.query('reminders',where:'property_id=?',whereArgs:[id],orderBy:'date ASC,time ASC');return r.map(Reminder.fromMap).toList();}
 Future<List<Reminder>> today(DateTime d)async{final a=DateTime(d.year,d.month,d.day),b=a.add(const Duration(days:1));final r=await db.query('reminders',where:'date>=? AND date<?',whereArgs:[a.millisecondsSinceEpoch,b.millisecondsSinceEpoch],orderBy:'time ASC');return r.map(Reminder.fromMap).toList();}
}
