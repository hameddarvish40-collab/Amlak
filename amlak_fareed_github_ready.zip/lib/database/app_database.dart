import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
class AppDatabase{
 AppDatabase._();static final instance=AppDatabase._();late Database db;
 Future<void> init()async{final p=join(await getDatabasesPath(),'amlak_fareed.db');db=await openDatabase(p,version:1,onCreate:(db,v)async{
 await db.execute('CREATE TABLE properties(id INTEGER PRIMARY KEY AUTOINCREMENT,transaction_type TEXT NOT NULL,property_type TEXT NOT NULL,area REAL NOT NULL,bedrooms INTEGER NOT NULL,direction TEXT NOT NULL,build_year INTEGER NOT NULL,sale_price INTEGER,deposit INTEGER,rent INTEGER,owner_name TEXT,owner_phone TEXT,description TEXT,category TEXT NOT NULL,statuses TEXT,amenities TEXT,is_archived INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)');
 await db.execute('CREATE TABLE property_images(id INTEGER PRIMARY KEY AUTOINCREMENT,property_id INTEGER NOT NULL,local_path TEXT NOT NULL,sort_order INTEGER NOT NULL,created_at INTEGER NOT NULL)');
 await db.execute('CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT,property_id INTEGER NOT NULL,date INTEGER NOT NULL,time TEXT NOT NULL,text TEXT NOT NULL)');
 });}
}
